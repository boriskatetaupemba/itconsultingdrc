from django.db import models
from wagtail.models import Page, Orderable
from wagtail.fields import RichTextField
from wagtail.admin.panels import FieldPanel, InlinePanel, MultiFieldPanel
from modelcluster.fields import ParentalKey


# ──────────────────────────────────────────────
# Inline models (repeatable sections)
# ──────────────────────────────────────────────

class HomePageStat(Orderable):
    page = ParentalKey('home.HomePage', related_name='stats', on_delete=models.CASCADE)
    value = models.CharField(max_length=20, help_text="Ex: 500+, 98%")
    label = models.CharField(max_length=100, help_text="Ex: Clients Satisfaits")

    panels = [
        FieldPanel('value'),
        FieldPanel('label'),
    ]

    class Meta(Orderable.Meta):
        verbose_name = "Statistique"


class HomePageService(Orderable):
    ICON_CHOICES = [
        ('bi bi-bar-chart-line', 'Graphique'),
        ('bi bi-cpu', 'CPU / Digital'),
        ('bi bi-people', 'Personnes'),
        ('bi bi-shield-check', 'Sécurité'),
        ('bi bi-gear', 'Engrenage'),
        ('bi bi-lightning', 'Éclair'),
        ('bi bi-globe', 'Globe'),
        ('bi bi-briefcase', 'Mallette'),
        ('bi bi-graph-up-arrow', 'Croissance'),
        ('bi bi-database', 'Base de données'),
        ('bi bi-cloud', 'Cloud'),
        ('bi bi-phone', 'Téléphone'),
        ('bi bi-code-slash', 'Code'),
        ('bi bi-diagram-3', 'Architecture'),
        ('bi bi-hdd-network', 'Réseau'),
        ('bi bi-terminal', 'Terminal'),
        ('bi bi-robot', 'IA / Robot'),
        ('bi bi-pie-chart', 'Analytique'),
        ('bi bi-git', 'Git / DevOps'),
        ('bi bi-server', 'Serveur'),
    ]
    COLOR_CHOICES = [
        ('icon-blue', 'Bleu'),
        ('icon-cyan', 'Cyan'),
        ('icon-green', 'Vert'),
        ('icon-orange', 'Orange'),
    ]

    page = ParentalKey('home.HomePage', related_name='services', on_delete=models.CASCADE)
    icon = models.CharField(max_length=50, choices=ICON_CHOICES, default='bi bi-bar-chart-line')
    color = models.CharField(max_length=20, choices=COLOR_CHOICES, default='icon-blue')
    title = models.CharField(max_length=100)
    description = models.TextField()

    panels = [
        FieldPanel('icon'),
        FieldPanel('color'),
        FieldPanel('title'),
        FieldPanel('description'),
    ]

    class Meta(Orderable.Meta):
        verbose_name = "Service"


class HomePageFeature(Orderable):
    page = ParentalKey('home.HomePage', related_name='features', on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    description = models.TextField()

    panels = [
        FieldPanel('title'),
        FieldPanel('description'),
    ]

    class Meta(Orderable.Meta):
        verbose_name = "Avantage"


class HomePageTestimonial(Orderable):
    page = ParentalKey('home.HomePage', related_name='testimonials', on_delete=models.CASCADE)
    text = models.TextField(help_text="Citation du client")
    author_name = models.CharField(max_length=100)
    author_role = models.CharField(max_length=100, help_text="Ex: DG, TechCorp SA")
    author_initials = models.CharField(max_length=5, help_text="Ex: JD")
    COLOR_CHOICES = [
        ('bg-primary', 'Bleu'),
        ('bg-info', 'Cyan'),
        ('bg-success', 'Vert'),
        ('bg-warning', 'Jaune'),
        ('bg-danger', 'Rouge'),
    ]
    author_color = models.CharField(max_length=20, choices=COLOR_CHOICES, default='bg-primary')
    stars = models.IntegerField(default=5, help_text="Nombre d'étoiles (1-5)")

    panels = [
        FieldPanel('text'),
        FieldPanel('author_name'),
        FieldPanel('author_role'),
        FieldPanel('author_initials'),
        FieldPanel('author_color'),
        FieldPanel('stars'),
    ]

    class Meta(Orderable.Meta):
        verbose_name = "Témoignage"


# ──────────────────────────────────────────────
# Main HomePage model
# ──────────────────────────────────────────────

class HomePage(Page):
    # ── Hero Section ──
    hero_tagline = models.CharField(max_length=200, default="Leader en Solutions Commerciales")
    hero_title_line1 = models.CharField(max_length=200, default="Propulsez votre", verbose_name="Titre ligne 1")
    hero_highlight_word = models.CharField(max_length=100, default="croissance", verbose_name="Mot en surbrillance")
    hero_title_line2 = models.CharField(max_length=200, default="avec IT-Consulting DRC", verbose_name="Titre ligne 2")
    hero_subtitle = models.TextField(
        default="Une équipe de développeurs seniors issus de grandes entreprises internationales, "
                "avec une solide expérience de terrain. Depuis 2016, nous concevons des systèmes "
                "d'information, développons des logiciels sur mesure et exploitons la puissance des données."
    )
    hero_cta_text = models.CharField(max_length=100, default="Découvrir nos services")
    hero_cta_secondary_text = models.CharField(max_length=100, default="En savoir plus")

    # ── Services Section ──
    services_tagline = models.CharField(max_length=100, default="Nos Services")
    services_title = models.CharField(max_length=200, default="Des solutions sur mesure")
    services_subtitle = models.TextField(
        default="Nous proposons une gamme complète de services pour répondre aux besoins "
                "de votre entreprise et accélérer votre croissance."
    )

    # ── Vision Section ──
    vision_tagline = models.CharField(max_length=100, default="Notre Vision", verbose_name="Titre Vision")
    vision_text = models.TextField(
        default="Être la meilleure adresse pour une solution digitale dans les entreprises et dans l'environnement.",
        verbose_name="Texte de la Vision",
        help_text="Utilisez des balises <em> pour mettre en surbrillance des mots clés."
    )

    # ── About Section ──
    about_mission_title = models.CharField(max_length=200, default="Notre Mission")
    about_mission_text = models.TextField(
        default="Fondée en 2016, IT-Consulting DRC réunit des développeurs et ingénieurs ayant forgé "
                "leur expertise au sein de grandes entreprises internationales — télécoms, banques, mines "
                "et industries. Forts de cette expérience de terrain, nous concevons des solutions "
                "technologiques robustes, éprouvées et parfaitement adaptées aux réalités du marché africain."
    )
    about_value1 = models.CharField(max_length=50, default="Innovation")
    about_value2 = models.CharField(max_length=50, default="Performance")
    about_tagline = models.CharField(max_length=100, default="Qui Sommes-Nous")
    about_title = models.CharField(max_length=200, default="Pourquoi choisir IT-Consulting DRC ?")
    about_subtitle = models.TextField(
        default="Des développeurs chevronnés, passés par les plus grandes entreprises du secteur, "
                "qui mettent leur expérience de terrain au service de vos projets IT."
    )

    # ── Testimonials Section ──
    testimonials_tagline = models.CharField(max_length=100, default="Témoignages")
    testimonials_title = models.CharField(max_length=200, default="Ce que disent nos clients")
    testimonials_subtitle = models.TextField(
        default="La satisfaction de nos clients est notre priorité absolue."
    )

    # ── Contact / CTA Section ──
    cta_title = models.CharField(max_length=200, default="Prêt à transformer votre entreprise ?")
    cta_subtitle = models.TextField(
        default="Contactez-nous dès aujourd'hui pour une consultation gratuite. "
                "Nos experts analyseront vos besoins et vous proposeront les meilleures solutions."
    )
    contact_phone = models.CharField(max_length=50, default="+243 81 234 5678")
    contact_email = models.EmailField(default="contact@itconsultingdrc.com")
    contact_address = models.CharField(max_length=200, default="Lubumbashi, RDC")
    cta_button_text = models.CharField(max_length=100, default="Envoyer un message")

    # ── Footer ──
    footer_description = models.TextField(
        default="Votre partenaire de confiance pour des solutions commerciales innovantes "
                "et une croissance durable."
    )
    facebook_url = models.URLField(blank=True, default="")
    linkedin_url = models.URLField(blank=True, default="")
    twitter_url = models.URLField(blank=True, default="")
    instagram_url = models.URLField(blank=True, default="")
    copyright_text = models.CharField(max_length=200, default="2026 IT-Consulting DRC. Tous droits réservés.")

    # ── Wagtail Admin Panels ──
    content_panels = Page.content_panels + [
        MultiFieldPanel([
            FieldPanel('hero_tagline'),
            FieldPanel('hero_title_line1'),
            FieldPanel('hero_highlight_word'),
            FieldPanel('hero_title_line2'),
            FieldPanel('hero_subtitle'),
            FieldPanel('hero_cta_text'),
            FieldPanel('hero_cta_secondary_text'),
        ], heading="Section Hero"),

        MultiFieldPanel([
            InlinePanel('stats', label="Statistique", min_num=1, max_num=6),
        ], heading="Barre de Statistiques"),

        MultiFieldPanel([
            FieldPanel('services_tagline'),
            FieldPanel('services_title'),
            FieldPanel('services_subtitle'),
            InlinePanel('services', label="Service", min_num=1, max_num=8),
        ], heading="Section Services"),

        MultiFieldPanel([
            FieldPanel('vision_tagline'),
            FieldPanel('vision_text'),
        ], heading="Section Vision / Objectif"),

        MultiFieldPanel([
            FieldPanel('about_mission_title'),
            FieldPanel('about_mission_text'),
            FieldPanel('about_value1'),
            FieldPanel('about_value2'),
            FieldPanel('about_tagline'),
            FieldPanel('about_title'),
            FieldPanel('about_subtitle'),
            InlinePanel('features', label="Avantage", min_num=1, max_num=8),
        ], heading="Section À Propos"),

        MultiFieldPanel([
            FieldPanel('testimonials_tagline'),
            FieldPanel('testimonials_title'),
            FieldPanel('testimonials_subtitle'),
            InlinePanel('testimonials', label="Témoignage", min_num=1, max_num=6),
        ], heading="Section Témoignages"),

        MultiFieldPanel([
            FieldPanel('cta_title'),
            FieldPanel('cta_subtitle'),
            FieldPanel('contact_phone'),
            FieldPanel('contact_email'),
            FieldPanel('contact_address'),
            FieldPanel('cta_button_text'),
        ], heading="Section Contact / CTA"),

        MultiFieldPanel([
            FieldPanel('footer_description'),
            FieldPanel('facebook_url'),
            FieldPanel('linkedin_url'),
            FieldPanel('twitter_url'),
            FieldPanel('instagram_url'),
            FieldPanel('copyright_text'),
        ], heading="Pied de Page"),
    ]

    template = 'home/home_page.html'

    class Meta:
        verbose_name = "Page d'Accueil"

    # Only allow one HomePage under the root
    parent_page_types = ['wagtailcore.Page']
    subpage_types = []

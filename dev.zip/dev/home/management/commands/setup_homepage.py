from django.core.management.base import BaseCommand
from wagtail.models import Page, Site
from home.models import (
    HomePage, HomePageStat, HomePageService,
    HomePageFeature, HomePageTestimonial,
)


class Command(BaseCommand):
    help = 'Create the initial IT-Consulting DRC homepage with all content'

    def handle(self, *args, **options):
        # Check if a HomePage already exists
        if HomePage.objects.exists():
            self.stdout.write(self.style.WARNING('HomePage already exists. Skipping.'))
            return

        # Get the default Wagtail root page
        root_page = Page.objects.get(depth=1)

        # Delete the default "Welcome to your new Wagtail site!" page if it exists
        Page.objects.filter(depth=2).exclude(
            content_type__model='homepage'
        ).delete()

        # Fix the tree after any deletions
        Page.fix_tree()

        # Reload root_page after fix
        root_page = Page.objects.get(depth=1)

        # Create the HomePage
        home_page = HomePage(
            title="IT-Consulting DRC - Solutions Commerciales",
            slug="home",
            seo_title="IT-Consulting DRC - Solutions Commerciales & Transformation Digitale",
            search_description="IT-Consulting DRC accompagne les entreprises dans leur transformation digitale avec des solutions innovantes.",
            # Hero
            hero_tagline="Leader en Solutions Commerciales",
            hero_title_line1="Propulsez votre",
            hero_highlight_word="croissance",
            hero_title_line2="avec IT-Consulting DRC",
            hero_subtitle=(
                "Nous accompagnons les entreprises dans leur transformation digitale "
                "avec des solutions innovantes et performantes. Expertise, fiabilité "
                "et résultats concrets."
            ),
            hero_cta_text="Découvrir nos services",
            hero_cta_secondary_text="En savoir plus",
            # Services
            services_tagline="Nos Services",
            services_title="Des solutions sur mesure",
            services_subtitle=(
                "Nous proposons une gamme complète de services pour répondre aux besoins "
                "de votre entreprise et accélérer votre croissance."
            ),
            # About
            about_mission_title="Notre Mission",
            about_mission_text=(
                "Depuis plus de 15 ans, IT-Consulting DRC s'engage à fournir des solutions "
                "commerciales de haute qualité qui transforment les défis en opportunités "
                "de croissance pour nos clients."
            ),
            about_value1="Excellence",
            about_value2="Innovation",
            about_tagline="À Propos de Nous",
            about_title="Pourquoi choisir IT-Consulting DRC ?",
            about_subtitle=(
                "Notre expertise couvre l'ensemble de la chaîne de valeur, "
                "offrant une approche intégrée pour répondre à vos enjeux commerciaux."
            ),
            # Testimonials
            testimonials_tagline="Témoignages",
            testimonials_title="Ce que disent nos clients",
            testimonials_subtitle="La satisfaction de nos clients est notre priorité absolue.",
            # CTA / Contact
            cta_title="Prêt à transformer votre entreprise ?",
            cta_subtitle=(
                "Contactez-nous dès aujourd'hui pour une consultation gratuite. "
                "Nos experts analyseront vos besoins et vous proposeront les meilleures solutions."
            ),
            contact_phone="+243 81 234 5678",
            contact_email="contact@itconsultingdrc.com",
            contact_address="Lubumbashi, RDC",
            cta_button_text="Envoyer un message",
            # Footer
            footer_description=(
                "Votre partenaire de confiance pour des solutions commerciales innovantes "
                "et une croissance durable."
            ),
            facebook_url="https://facebook.com/itconsultingdrc",
            linkedin_url="https://linkedin.com/company/itconsultingdrc",
            twitter_url="https://twitter.com/itconsultingdrc",
            instagram_url="https://instagram.com/itconsultingdrc",
            copyright_text="2026 IT-Consulting DRC. Tous droits réservés.",
        )

        root_page.add_child(instance=home_page)
        home_page.save_revision().publish()
        self.stdout.write(self.style.SUCCESS('HomePage created.'))

        # ── Stats ──
        stats_data = [
            ("500+", "Clients Satisfaits"),
            ("15+", "Années d'Expérience"),
            ("50+", "Experts Dédiés"),
            ("98%", "Taux de Réussite"),
        ]
        for i, (val, label) in enumerate(stats_data):
            HomePageStat.objects.create(page=home_page, sort_order=i, value=val, label=label)
        self.stdout.write(self.style.SUCCESS(f'  {len(stats_data)} stats created.'))

        # ── Services ──
        services_data = [
            ("bi bi-bar-chart-line", "icon-blue", "Conseil Stratégique",
             "Analyse approfondie et recommandations personnalisées pour optimiser vos performances commerciales."),
            ("bi bi-cpu", "icon-cyan", "Transformation Digitale",
             "Modernisez vos processus avec des technologies de pointe et des solutions cloud innovantes."),
            ("bi bi-people", "icon-green", "Gestion de Projets",
             "Pilotage expert de vos projets, de la conception à la livraison, avec des méthodologies agiles."),
            ("bi bi-shield-check", "icon-orange", "Cybersécurité",
             "Protection avancée de vos données et infrastructures contre les menaces numériques."),
        ]
        for i, (icon, color, title, desc) in enumerate(services_data):
            HomePageService.objects.create(
                page=home_page, sort_order=i, icon=icon, color=color, title=title, description=desc
            )
        self.stdout.write(self.style.SUCCESS(f'  {len(services_data)} services created.'))

        # ── Features ──
        features_data = [
            ("Expertise Reconnue",
             "Une équipe de professionnels certifiés avec une connaissance approfondie de votre secteur."),
            ("Approche Personnalisée",
             "Des solutions adaptées à vos besoins spécifiques et à votre budget."),
            ("Support 24/7",
             "Un accompagnement continu et réactif pour garantir la continuité de vos opérations."),
            ("Résultats Mesurables",
             "Des KPI clairs et un suivi rigoureux pour maximiser votre retour sur investissement."),
        ]
        for i, (title, desc) in enumerate(features_data):
            HomePageFeature.objects.create(page=home_page, sort_order=i, title=title, description=desc)
        self.stdout.write(self.style.SUCCESS(f'  {len(features_data)} features created.'))

        # ── Testimonials ──
        testimonials_data = [
            ("IT-Consulting DRC a transformé notre approche commerciale. Leur expertise "
             "et leur engagement nous ont permis d'augmenter notre chiffre d'affaires de 40%.",
             "Jean Dupont", "DG, TechCorp SA", "JD", "bg-primary", 5),
            ("Un partenaire de confiance. La transformation digitale pilotée par IT-Consulting DRC "
             "a révolutionné nos processus internes. Résultat : 30% de gains de productivité.",
             "Marie Lukanga", "DSI, MineralEx SARL", "ML", "bg-info", 5),
            ("Professionnalisme exemplaire et résultats au rendez-vous. "
             "L'équipe IT-Consulting DRC comprend véritablement les enjeux du marché africain.",
             "Patrick Kabongo", "CEO, AgriPlus Congo", "PK", "bg-success", 5),
        ]
        for i, (text, name, role, initials, color, stars) in enumerate(testimonials_data):
            HomePageTestimonial.objects.create(
                page=home_page, sort_order=i, text=text, author_name=name,
                author_role=role, author_initials=initials, author_color=color, stars=stars
            )
        self.stdout.write(self.style.SUCCESS(f'  {len(testimonials_data)} testimonials created.'))

        # ── Update the default Site to point to our HomePage ──
        site = Site.objects.get(is_default_site=True)
        site.root_page = home_page
        site.site_name = 'IT-Consulting DRC'
        site.save()
        self.stdout.write(self.style.SUCCESS('Default site updated to point to HomePage.'))
        self.stdout.write(self.style.SUCCESS('\nDone! Visit http://localhost:8000/ to see the site.'))
        self.stdout.write(self.style.SUCCESS('Admin: http://localhost:8000/admin/ (admin / admin123)'))

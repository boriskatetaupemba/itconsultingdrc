from django.core.management.base import BaseCommand
from home.models import (
    HomePage, HomePageStat, HomePageService,
    HomePageFeature, HomePageTestimonial,
)


class Command(BaseCommand):
    help = 'Update IT-Consulting DRC homepage content for IT development company'

    def handle(self, *args, **options):
        try:
            home_page = HomePage.objects.first()
        except HomePage.DoesNotExist:
            self.stdout.write(self.style.ERROR('No HomePage found. Run setup_homepage first.'))
            return

        if not home_page:
            self.stdout.write(self.style.ERROR('No HomePage found. Run setup_homepage first.'))
            return

        # ── Update Hero ──
        home_page.title = "IT-Consulting DRC - Développement Informatique & Solutions Digitales"
        home_page.seo_title = "IT-Consulting DRC - Systèmes d'Information, Développement Logiciel & Data Science"
        home_page.search_description = (
            "IT-Consulting DRC conçoit des systèmes d'information sur mesure, développe des logiciels "
            "performants et exploite la puissance des données pour transformer votre entreprise."
        )
        home_page.hero_tagline = "Expert en Développement Informatique"
        home_page.hero_title_line1 = "Transformez vos idées en"
        home_page.hero_highlight_word = "solutions digitales"
        home_page.hero_title_line2 = "avec IT-Consulting DRC"
        home_page.hero_subtitle = (
            "Conception de systèmes d'information, développement logiciel sur mesure, "
            "analyse de données et intelligence artificielle. "
            "Nous donnons vie à vos projets technologiques les plus ambitieux."
        )
        home_page.hero_cta_text = "Découvrir nos expertises"
        home_page.hero_cta_secondary_text = "Voir nos réalisations"

        # ── Update Services ──
        home_page.services_tagline = "Nos Expertises"
        home_page.services_title = "Des solutions technologiques de pointe"
        home_page.services_subtitle = (
            "De la conception de systèmes d'information au développement logiciel, "
            "en passant par la data science, nous couvrons l'ensemble de vos besoins IT."
        )

        # ── Update About ──
        home_page.about_mission_title = "Notre Mission"
        home_page.about_mission_text = (
            "Depuis sa création, IT-Consulting DRC s'est imposé comme un acteur majeur du développement "
            "informatique en Afrique. Notre équipe de développeurs, architectes logiciels et data "
            "scientists conçoit des solutions technologiques innovantes qui propulsent nos clients "
            "vers l'excellence opérationnelle."
        )
        home_page.about_value1 = "Innovation"
        home_page.about_value2 = "Performance"
        home_page.about_tagline = "Qui Sommes-Nous"
        home_page.about_title = "Pourquoi choisir IT-Consulting DRC ?"
        home_page.about_subtitle = (
            "Une expertise technique de pointe combinée à une parfaite compréhension "
            "de vos enjeux métiers pour des solutions IT qui font la différence."
        )

        # ── Update Testimonials ──
        home_page.testimonials_tagline = "Témoignages"
        home_page.testimonials_title = "Ils nous font confiance"
        home_page.testimonials_subtitle = (
            "Nos clients témoignent de l'impact de nos solutions sur leur transformation digitale."
        )

        # ── Update CTA / Contact ──
        home_page.cta_title = "Un projet informatique en tête ?"
        home_page.cta_subtitle = (
            "Parlez-nous de votre projet. Nos architectes et développeurs analyseront "
            "vos besoins et vous proposeront une solution technique sur mesure, "
            "de la conception au déploiement."
        )
        home_page.contact_phone = "+243 81 234 5678"
        home_page.contact_email = "contact@itconsultingdrc.com"
        home_page.contact_address = "Lubumbashi, RD Congo"
        home_page.cta_button_text = "Démarrer un projet"

        # ── Update Footer ──
        home_page.footer_description = (
            "Votre partenaire technologique de confiance pour la conception de systèmes "
            "d'information, le développement logiciel et l'exploitation intelligente des données."
        )
        home_page.facebook_url = "https://facebook.com/itconsultingdrc"
        home_page.linkedin_url = "https://linkedin.com/company/itconsultingdrc"
        home_page.twitter_url = "https://twitter.com/itconsultingdrc"
        home_page.instagram_url = "https://instagram.com/itconsultingdrc"
        home_page.copyright_text = "2026 IT-Consulting DRC. Tous droits réservés."

        home_page.save_revision().publish()
        self.stdout.write(self.style.SUCCESS('✓ HomePage content updated.'))

        # ── Update Stats ──
        home_page.stats.all().delete()
        stats_data = [
            ("200+", "Projets Livrés"),
            ("10+", "Années d'Expertise"),
            ("35+", "Ingénieurs & Développeurs"),
            ("99.9%", "Disponibilité Systèmes"),
        ]
        for i, (val, label) in enumerate(stats_data):
            HomePageStat.objects.create(page=home_page, sort_order=i, value=val, label=label)
        self.stdout.write(self.style.SUCCESS(f'  ✓ {len(stats_data)} stats updated.'))

        # ── Update Services ──
        home_page.services.all().delete()
        services_data = [
            ("bi bi-database", "icon-blue", "Systèmes d'Information",
             "Conception, développement et déploiement de SI sur mesure : ERP, CRM, "
             "plateformes métier, bases de données distribuées et architectures cloud-native."),
            ("bi bi-cpu", "icon-cyan", "Développement Logiciel",
             "Applications web et mobiles, API RESTful, microservices, "
             "solutions SaaS et logiciels embarqués avec les technologies les plus modernes."),
            ("bi bi-graph-up-arrow", "icon-green", "Data Science & IA",
             "Analyse prédictive, machine learning, tableaux de bord interactifs, "
             "ETL/pipelines de données et intelligence artificielle appliquée à vos métiers."),
            ("bi bi-shield-check", "icon-orange", "Cybersécurité & Cloud",
             "Audit de sécurité, protection des infrastructures, migration cloud, "
             "DevOps, CI/CD et supervision 24/7 de vos environnements de production."),
        ]
        for i, (icon, color, title, desc) in enumerate(services_data):
            HomePageService.objects.create(
                page=home_page, sort_order=i, icon=icon, color=color, title=title, description=desc
            )
        self.stdout.write(self.style.SUCCESS(f'  ✓ {len(services_data)} services updated.'))

        # ── Update Features ──
        home_page.features.all().delete()
        features_data = [
            ("Équipe Technique Certifiée",
             "Développeurs seniors, architectes cloud et data engineers certifiés AWS, Azure et Google Cloud."),
            ("Méthodologies Agiles",
             "Scrum, Kanban et DevOps pour des livraisons itératives, transparentes et alignées sur vos priorités."),
            ("Code Qualité & Tests",
             "TDD, revue de code systématique, intégration continue et couverture de tests à 90%+ sur chaque projet."),
            ("Support & Maintenance",
             "SLA garantis, monitoring proactif, maintenance évolutive et support technique réactif 24/7."),
        ]
        for i, (title, desc) in enumerate(features_data):
            HomePageFeature.objects.create(page=home_page, sort_order=i, title=title, description=desc)
        self.stdout.write(self.style.SUCCESS(f'  ✓ {len(features_data)} features updated.'))

        # ── Update Testimonials ──
        home_page.testimonials.all().delete()
        testimonials_data = [
            ("IT-Consulting DRC a développé notre plateforme ERP de bout en bout. "
             "Leur maîtrise des systèmes d'information et leur rigueur dans le suivi "
             "du projet nous ont permis de digitaliser 100% de nos processus métier en 6 mois.",
             "Olivier Mbaya", "DSI, Katanga Mining Corp", "OM", "bg-primary", 5),
            ("Grâce à l'équipe data science de IT-Consulting DRC, nous exploitons désormais nos données "
             "commerciales avec des dashboards temps réel et des modèles prédictifs. "
             "Résultat : +35% d'optimisation de notre supply chain.",
             "Clarisse Ilunga", "Directrice Analytics, LogiTrans SA", "CI", "bg-info", 5),
            ("Le développement de notre application mobile par IT-Consulting DRC a été exemplaire. "
             "Interface intuitive, performances optimales et déploiement dans les délais. "
             "Plus de 50 000 utilisateurs actifs en 3 mois.",
             "Patrick Kasongo", "CEO, FinTech Congo", "PK", "bg-success", 5),
        ]
        for i, (text, name, role, initials, color, stars) in enumerate(testimonials_data):
            HomePageTestimonial.objects.create(
                page=home_page, sort_order=i, text=text, author_name=name,
                author_role=role, author_initials=initials, author_color=color, stars=stars
            )
        self.stdout.write(self.style.SUCCESS(f'  ✓ {len(testimonials_data)} testimonials updated.'))

        self.stdout.write(self.style.SUCCESS('\n✅ Contenu mis à jour pour société de développement informatique !'))
        self.stdout.write(self.style.SUCCESS('Visitez http://localhost:8000/ pour voir le résultat.'))
